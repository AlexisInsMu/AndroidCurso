package com.alexisnovo.androidcurso

fun main(){
	ifBasico()
}

fun ifBasico() {
	val name = "Alex"

	if(name == "alex"){
		println("la variable name es pepe")
	}
}
